import Foundation

enum NodeKind: String, Codable, CaseIterable {
    case shadowsocks, vmess, vless, trojan, hysteria2
}

struct ProxyNode: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var kind: NodeKind
    var server: String
    var port: Int
    var password: String?      // ss/trojan/hy2 密码；vmess/vless 为 uuid
    var method: String?        // ss 加密方式
    var security: String?      // none / tls / reality
    var sni: String?
    var network: String?       // tcp / ws / grpc
    var path: String?
    var host: String?
    var flow: String?
    var alterID: Int?
    var publicKey: String?     // reality
    var shortID: String?
    var fingerprint: String?
    var allowInsecure = false
    var subscriptionID: UUID?
}

struct Subscription: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var url: String
    var updatedAt: Date?
}

enum GroupMode: String, Codable, CaseIterable, Identifiable {
    case select, urltest
    var id: String { rawValue }
    var title: String { self == .select ? "手动选择" : "自动测速" }
}

enum ProxyDNS: String, Codable, CaseIterable, Identifiable {
    case google, cloudflare
    var id: String { rawValue }
    var title: String { self == .google ? "Google 8.8.8.8" : "Cloudflare 1.1.1.1" }
}

struct AppSettings: Codable {
    var mode: GroupMode = .urltest
    var selectedNodeID: UUID?
    var blockQUIC = true
    var proxyDNS: ProxyDNS = .google
    var ruleSetBase = "https://cdn.jsdelivr.net/gh/SagerNet"
}

struct AppState: Codable {
    var nodes: [ProxyNode] = []
    var subscriptions: [Subscription] = []
    var settings = AppSettings()
}
