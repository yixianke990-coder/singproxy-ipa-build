import Libbox
import Network
import NetworkExtension
import Security

/// 参考 sing-box-for-apple 的 ExtensionPlatformInterface。
/// 协议方法随 Libbox 版本略有增减：编译报错时用 Xcode 的 “Add protocol stubs” 补齐，
/// 再对照 sing-box-for-apple 对应 tag 的实现核对签名。
final class PlatformInterface: NSObject, LibboxPlatformInterfaceProtocol {
    private unowned let tunnel: NEPacketTunnelProvider
    private var monitor: NWPathMonitor?
    private let queue = DispatchQueue(label: "singproxy.path")

    init(_ tunnel: NEPacketTunnelProvider) { self.tunnel = tunnel }

    // MARK: TUN —— 仅 IPv4，全局默认路由
    func openTun(_ options: LibboxTunOptionsProtocol?, ret0_: UnsafeMutablePointer<Int32>?) throws {
        let s = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "127.0.0.1")
        s.mtu = 1400

        let v4 = NEIPv4Settings(addresses: ["172.19.0.1"], subnetMasks: ["255.255.255.252"])
        v4.includedRoutes = [NEIPv4Route.default()]
        s.ipv4Settings = v4
        // 故意不设置 ipv6Settings：不创建任何 IPv6 地址/路由

        let dns = NEDNSSettings(servers: ["172.19.0.2"])   // 进隧道后由 sing-box hijack-dns 接管
        dns.matchDomains = [""]
        s.dnsSettings = dns

        var failure: Error?
        let sem = DispatchSemaphore(value: 0)
        tunnel.setTunnelNetworkSettings(s) { failure = $0; sem.signal() }
        sem.wait()
        if let failure { throw failure }

        if let fd = tunnel.packetFlow.value(forKeyPath: "socket.fileDescriptor") as? Int32 {
            ret0_?.pointee = fd
            return
        }
        let fd = LibboxGetTunnelFileDescriptor()
        guard fd != -1 else { throw NSError(domain: "SingProxy", code: 1, userInfo: [NSLocalizedDescriptionKey: "拿不到 TUN 文件描述符"]) }
        ret0_?.pointee = fd
    }

    // MARK: 默认网卡监控
    func startDefaultInterfaceMonitor(_ listener: LibboxInterfaceUpdateListenerProtocol?) throws {
        let m = NWPathMonitor()
        m.pathUpdateHandler = { [weak self] path in self?.report(path, listener) }
        m.start(queue: queue)
        monitor = m
    }

    func closeDefaultInterfaceMonitor(_ listener: LibboxInterfaceUpdateListenerProtocol?) throws {
        monitor?.cancel()
        monitor = nil
    }

    private func report(_ path: Network.NWPath, _ l: LibboxInterfaceUpdateListenerProtocol?) {
        guard path.status != .unsatisfied, let i = path.availableInterfaces.first else {
            l?.updateDefaultInterface("", interfaceIndex: -1, isExpensive: false, isConstrained: false)
            return
        }
        l?.updateDefaultInterface(i.name, interfaceIndex: Int32(i.index),
                                  isExpensive: path.isExpensive, isConstrained: path.isConstrained)
    }

    func getInterfaces() throws -> LibboxNetworkInterfaceIteratorProtocol {
        guard let path = monitor?.currentPath, path.status != .unsatisfied else { return InterfaceIterator([]) }
        let list: [LibboxNetworkInterface] = path.availableInterfaces.map { it in
            let i = LibboxNetworkInterface()
            i.name = it.name
            i.index = Int32(truncatingIfNeeded: it.index)
            switch it.type {
            case .wifi: i.type = LibboxInterfaceTypeWIFI
            case .cellular: i.type = LibboxInterfaceTypeCellular
            case .wiredEthernet: i.type = LibboxInterfaceTypeEthernet
            default: i.type = LibboxInterfaceTypeOther
            }
            return i
        }
        return InterfaceIterator(list)
    }

    // MARK: 其余必需方法（iOS 上基本是固定返回值）
    func usePlatformAutoDetectControl() -> Bool { true }
    func autoDetectControl(_ fd: Int32) throws {}          // NE 内的 socket 自动绕过隧道
    func useProcFS() -> Bool { false }
    func underNetworkExtension() -> Bool { true }
    func includeAllNetworks() -> Bool { false }
    func clearDNSCache() {}
    func readWIFIState() -> LibboxWIFIState? { nil }
    func writeLog(_ message: String?) { if let message { NSLog("sing-box: %@", message) } }
    func localDNSTransport() -> LibboxLocalDNSTransportProtocol? { nil }
    func send(_ notification: LibboxNotification?) throws {}
    func systemCertificates() -> LibboxStringIteratorProtocol? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassCertificate,
            kSecMatchLimit as String: kSecMatchLimitAll,
            kSecReturnData as String: true,
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let certs = result as? [Data] else { return nil }
        return StringIterator(certs.map { $0.base64EncodedString() })
    }

    func findConnectionOwner(_ ipProtocol: Int32, sourceAddress: String?, sourcePort: Int32,
                             destinationAddress: String?, destinationPort: Int32,
                             ret0_: UnsafeMutablePointer<Int32>?) throws {
        throw NSError(domain: "SingProxy", code: 2, userInfo: [NSLocalizedDescriptionKey: "not supported"])
    }
    func packageName(byUid uid: Int32, error: NSErrorPointer) -> String { "" }
    func uid(byPackageName packageName: String?, ret0_: UnsafeMutablePointer<Int32>?) throws {
        throw NSError(domain: "SingProxy", code: 2, userInfo: [NSLocalizedDescriptionKey: "not supported"])
    }
}

private final class InterfaceIterator: NSObject, LibboxNetworkInterfaceIteratorProtocol {
    private var it: IndexingIterator<[LibboxNetworkInterface]>
    private var current: LibboxNetworkInterface?
    init(_ a: [LibboxNetworkInterface]) { it = a.makeIterator() }
    func hasNext() -> Bool { current = it.next(); return current != nil }
    func next() -> LibboxNetworkInterface? { current }
}

private final class StringIterator: NSObject, LibboxStringIteratorProtocol {
    private let items: [String]
    private var it: IndexingIterator<[String]>
    private var current: String?
    init(_ a: [String]) { items = a; it = a.makeIterator() }
    func hasNext() -> Bool { current = it.next(); return current != nil }
    func next() -> String { current ?? "" }
    func len() -> Int32 { Int32(items.count) }
}
