import SwiftUI

// iOS 18：Material 回退；iOS 26 / 27：Liquid Glass。
// iOS 27 里 Liquid Glass 只是在 26 的基础上精修，API 不变，所以 #available(iOS 26, *) 一个分支就覆盖两代。
// 文字/图标一律用语义色（.primary/.secondary），因为用户可以在系统里调玻璃透明度。

@available(iOS 26, *)
private func makeGlass(tint: Color?, interactive: Bool) -> Glass {
    var g = Glass.regular
    if let tint { g = g.tint(tint) }
    if interactive { g = g.interactive() }
    return g
}

extension View {
    @ViewBuilder
    func adaptiveGlass(cornerRadius: CGFloat = 22, tint: Color? = nil, interactive: Bool = false) -> some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        if #available(iOS 26, *) {
            self.glassEffect(makeGlass(tint: tint, interactive: interactive), in: shape)
        } else {
            self
                .background(.ultraThinMaterial, in: shape)
                .background((tint ?? .clear).opacity(0.6), in: shape)
                .overlay(shape.strokeBorder(.white.opacity(0.18), lineWidth: 0.5))
        }
    }

    @ViewBuilder
    func adaptiveButtonStyle(prominent: Bool = false) -> some View {
        if #available(iOS 26, *) {
            if prominent { self.buttonStyle(.glassProminent) } else { self.buttonStyle(.glass) }
        } else {
            if prominent { self.buttonStyle(.borderedProminent) } else { self.buttonStyle(.bordered) }
        }
    }
}

/// 多块玻璃放一起时用容器，让它们能融合/变形，也更省 GPU
struct AdaptiveGlassContainer<Content: View>: View {
    var spacing: CGFloat = 12
    @ViewBuilder var content: Content
    var body: some View {
        if #available(iOS 26, *) {
            GlassEffectContainer(spacing: spacing) { content }
        } else {
            content
        }
    }
}

/// 玻璃需要有东西可折射，所以给一个 MeshGradient 背景（iOS 18+）
struct AuroraBackground: View {
    @Environment(\.colorScheme) private var scheme
    private let points: [SIMD2<Float>] = [
        [0, 0], [0.5, 0], [1, 0],
        [0, 0.5], [0.55, 0.45], [1, 0.5],
        [0, 1], [0.5, 1], [1, 1],
    ]
    private var colors: [Color] {
        if scheme == .dark {
            return [.indigo, .blue, .purple, .black, .indigo, .teal, .black, .blue, .indigo]
        }
        return [.cyan, .blue, .purple, .mint, .white, .indigo, .teal, .cyan, .blue]
    }
    var body: some View {
        MeshGradient(width: 3, height: 3, points: points, colors: colors)
            .opacity(scheme == .dark ? 0.75 : 0.45)
            .ignoresSafeArea()
    }
}
