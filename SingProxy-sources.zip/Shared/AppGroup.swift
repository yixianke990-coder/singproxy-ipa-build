import Foundation

enum AppGroup {
    // 已按本工程的 Bundle ID 填好（App: com.singproxy.app）
    static let id = "group.com.singproxy.app"
    static let tunnelBundleID = "com.singproxy.app.tunnel"

    /// 当前签名是否包含 App Group 共享权限。
    /// 自签证书/免费签名通常不带这个权限，此时 containerURL 返回 nil。
    static var hasAppGroup: Bool {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: id) != nil
    }

    static var container: URL {
        if let url = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: id) {
            return url
        }
        // 回退：签名缺少 App Group 权限时用应用自身目录，避免启动直接闪退。
        // 注意：此模式下 App 与隧道扩展无法共享配置，隧道不可用（界面会给出提示）。
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = base.appendingPathComponent("SingProxyShared", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }
    static var configURL: URL { container.appendingPathComponent("config.json") }
    static var stateURL: URL { container.appendingPathComponent("state.json") }
    static var workingDir: URL { container.appendingPathComponent("work", isDirectory: true) }
}
