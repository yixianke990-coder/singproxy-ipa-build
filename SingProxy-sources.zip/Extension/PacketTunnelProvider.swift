import Libbox
import NetworkExtension

final class PacketTunnelProvider: NEPacketTunnelProvider {
    private var service: LibboxBoxService?
    private var platform: PlatformInterface?

    override func startTunnel(options: [String: NSObject]?) async throws {
        try? FileManager.default.createDirectory(at: AppGroup.workingDir, withIntermediateDirectories: true)

        // 注意：不同 Libbox 版本的 Setup 签名不同（旧版为 LibboxSetup(base, work, temp, isTVOS, &err)）
        let opts = LibboxSetupOptions()
        opts.basePath = AppGroup.container.path
        opts.workingPath = AppGroup.workingDir.path
        opts.tempPath = NSTemporaryDirectory()
        var err: NSError?
        LibboxSetup(opts, &err)
        if let err { throw err }
        LibboxSetMemoryLimit(true)          // iOS 扩展内存上限约 50MB，必须开

        let config = try String(contentsOf: AppGroup.configURL, encoding: .utf8)
        let platform = PlatformInterface(self)
        self.platform = platform
        var e2: NSError?
        let svc = LibboxNewService(config, platform, &e2)
        if let e2 { throw e2 }
        try svc?.start()
        service = svc
    }

    override func stopTunnel(with reason: NEProviderStopReason) async {
        try? service?.close()
        service = nil
        platform = nil
    }
}
