import SwiftUI

// iOS 18：经典 TabBar。iOS 26/27：用新 SDK 编译后，TabView / NavigationStack / 工具栏自动变成 Liquid Glass，
// 这里不需要（也不应该）再手动给系统控件套玻璃。只有自定义控件才用 adaptiveGlass。

struct RootView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        TabView {
            Tab("连接", systemImage: "power") { HomeView() }
            Tab("节点", systemImage: "network") { NodesView() }
            Tab("设置", systemImage: "gearshape") { SettingsView() }
        }
        .overlay(alignment: .top) {
            if let t = model.toast {
                Text(t)
                    .font(.subheadline)
                    .padding(.horizontal, 16).padding(.vertical, 10)
                    .adaptiveGlass(cornerRadius: 20)
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .task(id: t) {
                        try? await Task.sleep(for: .seconds(2.5))
                        model.toast = nil
                    }
            }
        }
        .overlay(alignment: .bottom) {
            if !AppGroup.hasAppGroup {
                Text("当前签名缺少共享权限：能打开和编辑节点，但隧道扩展读不到配置、无法真正连接（需带 App Group + 网络扩展权限的签名）")
                    .font(.footnote)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 14).padding(.vertical, 8)
                    .adaptiveGlass(cornerRadius: 14)
                    .padding(.horizontal, 16).padding(.bottom, 60)
            }
        }
        .animation(.snappy, value: model.toast)
    }
}

// MARK: - 连接
struct HomeView: View {
    @EnvironmentObject private var model: AppModel

    private var nodeText: String {
        let s = model.state
        if s.nodes.isEmpty { return "还没有节点" }
        if s.settings.mode == .urltest { return "自动测速 · \(s.nodes.count) 个节点" }
        return s.nodes.first { $0.id == s.settings.selectedNodeID }?.name ?? s.nodes[0].name
    }

    var body: some View {
        ZStack {
            AuroraBackground()
            VStack(spacing: 22) {
                Spacer()
                Button { Task { await model.toggle() } } label: {
                    Image(systemName: "power")
                        .font(.system(size: 56, weight: .semibold))
                        .foregroundStyle(model.isOn ? Color.green : Color.primary)
                        .frame(width: 168, height: 168)
                        .contentShape(Circle())
                }
                .buttonStyle(.plain)
                .adaptiveGlass(cornerRadius: 84, tint: model.isOn ? Color.green.opacity(0.35) : nil, interactive: true)

                Text(model.statusText).font(.title2.weight(.semibold))
                Text(nodeText).font(.subheadline).foregroundStyle(.secondary)
                Spacer()

                AdaptiveGlassContainer(spacing: 10) {
                    HStack(spacing: 10) {
                        chip("IPv4 TUN"); chip("国内直连"); chip("DoH")
                    }
                }
                Picker("模式", selection: $model.state.settings.mode) {
                    ForEach(GroupMode.allCases) { Text($0.title).tag($0) }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 32)
                if model.isOn {
                    Text("切换模式或节点后，重新连接生效").font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(.bottom, 24)
        }
    }

    private func chip(_ t: String) -> some View {
        Text(t).font(.footnote.weight(.medium))
            .padding(.horizontal, 12).padding(.vertical, 7)
            .adaptiveGlass(cornerRadius: 14)
    }
}

// MARK: - 节点
struct NodesView: View {
    @EnvironmentObject private var model: AppModel
    @State private var showAdd = false

    var body: some View {
        NavigationStack {
            List {
                Button {
                    model.state.settings.mode = .urltest
                } label: {
                    row("自动测速", "urltest · 自动选延迟最低的节点",
                        selected: model.state.settings.mode == .urltest)
                }
                ForEach(model.state.nodes) { n in
                    Button {
                        model.state.settings.selectedNodeID = n.id
                        model.state.settings.mode = .select
                    } label: {
                        row(n.name, "\(n.kind.rawValue) · \(n.server):\(n.port)",
                            selected: model.state.settings.mode == .select && model.state.settings.selectedNodeID == n.id)
                    }
                }
                .onDelete { model.state.nodes.remove(atOffsets: $0) }
            }
            .scrollContentBackground(.hidden)
            .background(AuroraBackground())
            .navigationTitle("节点")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("刷新订阅", systemImage: "arrow.clockwise") { Task { await model.refreshAll() } }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("添加", systemImage: "plus") { showAdd = true }
                }
            }
            .overlay {
                if model.state.nodes.isEmpty {
                    ContentUnavailableView("还没有节点", systemImage: "network",
                                           description: Text("点右上角 + 粘贴节点链接或订阅地址"))
                }
            }
            .sheet(isPresented: $showAdd) { AddSheet() }
        }
    }

    private func row(_ title: String, _ sub: String, selected: Bool) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text(title).foregroundStyle(.primary)
                Text(sub).font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
            if selected { Image(systemName: "checkmark.circle.fill").foregroundStyle(.tint) }
        }
    }
}

struct AddSheet: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var text = ""

    var body: some View {
        NavigationStack {
            VStack(spacing: 16) {
                TextEditor(text: $text)
                    .font(.system(.footnote, design: .monospaced))
                    .scrollContentBackground(.hidden)
                    .padding(12)
                    .frame(minHeight: 180)
                    .adaptiveGlass(cornerRadius: 20)
                Text("支持 ss / vmess / vless / trojan / hysteria2 链接（可多行），或 http(s) 订阅地址")
                    .font(.footnote).foregroundStyle(.secondary)
                AdaptiveGlassContainer {
                    HStack(spacing: 12) {
                        Button("粘贴", systemImage: "doc.on.clipboard") { text = UIPasteboard.general.string ?? text }
                            .adaptiveButtonStyle()
                        Button("导入", systemImage: "square.and.arrow.down") {
                            model.importText(text); dismiss()
                        }
                        .adaptiveButtonStyle(prominent: true)
                        .disabled(text.isEmpty)
                    }
                }
                Spacer()
            }
            .padding()
            .navigationTitle("添加节点")
            .navigationBarTitleDisplayMode(.inline)
        }
        .presentationDetents([.medium, .large])
    }
}

// MARK: - 设置
struct SettingsView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        NavigationStack {
            Form {
                Section("网络") {
                    LabeledContent("TUN", value: "仅 IPv4 · 全局")
                    LabeledContent("国内 DNS", value: "阿里 DoH · 腾讯 DoH")
                    LabeledContent("前置解析", value: "223.5.5.5 / 119.29.29.29")
                    LabeledContent("代理 DNS", value: "8.8.8.8 / 1.1.1.1（经代理）")
                }
                Section {
                    Picker("代理 DNS 主选", selection: $model.state.settings.proxyDNS) {
                        ForEach(ProxyDNS.allCases) { Text($0.title).tag($0) }
                    }
                    Toggle("屏蔽 QUIC（UDP 443）", isOn: $model.state.settings.blockQUIC)
                } footer: {
                    Text("修改后重新连接生效。未打包本地规则集时，会从下面的地址下载 geosite-cn / geoip-cn。")
                }
                Section("规则集源") {
                    TextField("规则集前缀", text: $model.state.settings.ruleSetBase)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .font(.footnote)
                }
            }
            .scrollContentBackground(.hidden)
            .background(AuroraBackground())
            .navigationTitle("设置")
        }
    }
}
