import Foundation

/// 解析 ss:// vmess:// vless:// trojan:// hysteria2:// 分享链接，以及 base64/明文订阅
enum LinkParser {
    static func parse(_ raw: String) -> ProxyNode? {
        let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let r = s.range(of: "://") else { return nil }
        switch s[..<r.lowerBound].lowercased() {
        case "ss": return shadowsocks(s)
        case "vmess": return vmess(s)
        case "vless": return generic(s, .vless)
        case "trojan": return generic(s, .trojan)
        case "hysteria2", "hy2": return generic(s, .hysteria2)
        default: return nil
        }
    }

    static func parseSubscription(_ body: String) -> [ProxyNode] {
        var text = body
        if !body.contains("://"), let d = b64(body), let t = String(data: d, encoding: .utf8) { text = t }
        return text.split(whereSeparator: \.isNewline).compactMap { parse(String($0)) }
    }

    // MARK: - helpers
    static func b64(_ s: String) -> Data? {
        var t = s.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        while t.count % 4 != 0 { t += "=" }
        return Data(base64Encoded: t)
    }

    private static func splitFragment(_ s: String) -> (String, String?) {
        guard let i = s.firstIndex(of: "#") else { return (s, nil) }
        let frag = String(s[s.index(after: i)...])
        return (String(s[..<i]), frag.removingPercentEncoding ?? frag)
    }

    private static func hostPort(_ hp: String) -> (String, Int)? {
        guard let i = hp.lastIndex(of: ":"), let p = Int(hp[hp.index(after: i)...]) else { return nil }
        return (String(hp[..<i]).trimmingCharacters(in: CharacterSet(charactersIn: "[]")), p)
    }

    // MARK: - ss
    private static func shadowsocks(_ s: String) -> ProxyNode? {
        if s.contains("plugin=") { return nil }          // 暂不支持 SIP003 插件
        let (b0, name) = splitFragment(String(s.dropFirst(5)))
        var body = b0
        if let q = body.firstIndex(of: "?") { body = String(body[..<q]) }
        var userinfo: String
        let hostport: String
        if let at = body.lastIndex(of: "@") {
            userinfo = String(body[..<at])
            hostport = String(body[body.index(after: at)...])
            if !userinfo.contains(":") {
                guard let d = b64(userinfo), let t = String(data: d, encoding: .utf8) else { return nil }
                userinfo = t
            } else {
                userinfo = userinfo.removingPercentEncoding ?? userinfo
            }
        } else {
            guard let d = b64(body), let t = String(data: d, encoding: .utf8),
                  let at = t.lastIndex(of: "@") else { return nil }
            userinfo = String(t[..<at])
            hostport = String(t[t.index(after: at)...])
        }
        guard let c = userinfo.firstIndex(of: ":"), let hp = hostPort(hostport) else { return nil }
        var n = ProxyNode(name: name ?? hp.0, kind: .shadowsocks, server: hp.0, port: hp.1)
        n.method = String(userinfo[..<c])
        n.password = String(userinfo[userinfo.index(after: c)...])
        return n
    }

    // MARK: - vmess
    private static func vmess(_ s: String) -> ProxyNode? {
        guard let d = b64(String(s.dropFirst(8))),
              let j = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
              let host = j["add"] as? String else { return nil }
        func str(_ k: String) -> String? { (j[k] as? String) ?? (j[k] as? Int).map(String.init) }
        guard let port = Int(str("port") ?? ""), let id = str("id") else { return nil }
        var n = ProxyNode(name: str("ps") ?? host, kind: .vmess, server: host, port: port)
        n.password = id
        n.alterID = Int(str("aid") ?? "0")
        n.network = str("net")
        n.path = str("path")
        n.host = str("host")
        n.security = str("tls") == "tls" ? "tls" : "none"
        n.sni = str("sni") ?? str("host")
        return n
    }

    // MARK: - vless / trojan / hysteria2
    private static func generic(_ s: String, _ kind: NodeKind) -> ProxyNode? {
        let (body, name) = splitFragment(s)
        guard let u = URLComponents(string: body), let host = u.host, let port = u.port else { return nil }
        var q: [String: String] = [:]
        for i in u.queryItems ?? [] { if let v = i.value { q[i.name] = v } }
        var n = ProxyNode(name: name ?? host, kind: kind, server: host, port: port)
        n.password = [u.user, u.password].compactMap { $0 }.joined(separator: ":")
        n.security = q["security"] ?? (kind == .vless ? "none" : "tls")
        n.sni = q["sni"] ?? q["peer"]
        n.network = q["type"]
        n.path = q["path"] ?? q["serviceName"]
        n.host = q["host"]
        n.flow = q["flow"]
        n.publicKey = q["pbk"]
        n.shortID = q["sid"]
        n.fingerprint = q["fp"]
        n.allowInsecure = q["allowInsecure"] == "1" || q["insecure"] == "1"
        return n
    }
}
