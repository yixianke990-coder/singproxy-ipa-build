import Foundation

enum AppGroup {
    // 已按本工程的 Bundle ID 填好（App: com.singproxy.app）
    static let id = "group.com.singproxy.app"
    static let tunnelBundleID = "com.singproxy.app.tunnel"

    static var container: URL {
        FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: id)!
    }
    static var configURL: URL { container.appendingPathComponent("config.json") }
    static var stateURL: URL { container.appendingPathComponent("state.json") }
    static var workingDir: URL { container.appendingPathComponent("work", isDirectory: true) }
}
