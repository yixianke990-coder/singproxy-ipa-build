import Foundation

enum ConfigError: LocalizedError {
    case noNodes
    var errorDescription: String? { "还没有节点，请先在“节点”页导入链接或订阅" }
}

/// 生成 sing-box 1.12+ 格式配置
///
/// 设计：
/// - TUN 仅 IPv4（172.19.0.1/30），全局接管 IPv4；DNS 全程 ipv4_only，不返回 AAAA
/// - 国内：阿里 DoH(dns.alidns.com，前置 223.5.5.5) / 腾讯 DoH(doh.pub，前置 119.29.29.29)，直连
/// - 代理：8.8.8.8 与 1.1.1.1 的 DoH，走代理出站解析
/// - 节点域名用 223.5.5.5 解析（前置），避免回环
enum ConfigBuilder {
    static let tencentSuffixes = [
        "qq.com", "wechat.com", "tencent.com", "tencent-cloud.com", "myqcloud.com",
        "gtimg.com", "gtimg.cn", "qpic.cn", "qlogo.cn", "idqqimg.com",
    ]

    static func build(_ s: AppState) throws -> String {
        guard !s.nodes.isEmpty else { throw ConfigError.noNodes }
        let st = s.settings

        // ---- outbounds
        var tags: [String] = []
        var nodeOutbounds: [[String: Any]] = []
        for (i, n) in s.nodes.enumerated() {
            let tag = "\(i + 1) \(n.name)"
            tags.append(tag)
            nodeOutbounds.append(outbound(n, tag: tag))
        }
        let idx = s.nodes.firstIndex { $0.id == st.selectedNodeID } ?? 0
        let defaultTag: String = st.mode == .urltest ? "auto" : tags[idx]
        let selector: [String: Any] = [
            "type": "selector", "tag": "proxy",
            "outbounds": ["auto"] + tags, "default": defaultTag,
        ]
        let urltest: [String: Any] = [
            "type": "urltest", "tag": "auto", "outbounds": tags,
            "url": "https://www.gstatic.com/generate_204", "interval": "3m", "tolerance": 50,
        ]
        let direct: [String: Any] = ["type": "direct", "tag": "direct"]
        let outbounds: [[String: Any]] = [selector, urltest, direct] + nodeOutbounds

        // ---- inbound：仅 IPv4 的全局 TUN
        let tun: [String: Any] = [
            "type": "tun", "tag": "tun-in",
            "address": ["172.19.0.1/30"],
            "mtu": 1400, "auto_route": true, "strict_route": false,
            "stack": "mixed",
        ]

        // ---- DNS
        func udp(_ tag: String, _ ip: String) -> [String: Any] {
            ["type": "udp", "tag": tag, "server": ip]
        }
        func doh(_ tag: String, _ host: String, resolver: String? = nil, detour: String? = nil) -> [String: Any] {
            var d: [String: Any] = ["type": "https", "tag": tag, "server": host, "path": "/dns-query"]
            if let resolver { d["domain_resolver"] = resolver }
            if let detour { d["detour"] = detour }
            return d
        }
        let dnsServers: [[String: Any]] = [
            udp("boot-ali", "223.5.5.5"),
            udp("boot-tencent", "119.29.29.29"),
            doh("doh-ali", "dns.alidns.com", resolver: "boot-ali"),
            doh("doh-tencent", "doh.pub", resolver: "boot-tencent"),
            doh("dns-google", "8.8.8.8", detour: "proxy"),
            doh("dns-cloudflare", "1.1.1.1", detour: "proxy"),
        ]
        let dnsRules: [[String: Any]] = [
            ["domain_suffix": tencentSuffixes, "action": "route", "server": "doh-tencent"],
            ["rule_set": ["geosite-cn"], "action": "route", "server": "doh-ali"],
        ]
        let finalDNS: String = st.proxyDNS == .google ? "dns-google" : "dns-cloudflare"
        let dns: [String: Any] = [
            "servers": dnsServers, "rules": dnsRules,
            "final": finalDNS, "strategy": "ipv4_only",
        ]

        // ---- route：国内直连，其余走代理
        var rules: [[String: Any]] = [
            ["action": "sniff"],
            ["protocol": "dns", "action": "hijack-dns"],
            ["ip_is_private": true, "action": "route", "outbound": "direct"],
            ["rule_set": ["geosite-cn"], "action": "route", "outbound": "direct"],
            ["rule_set": ["geoip-cn"], "action": "route", "outbound": "direct"],
        ]
        if st.blockQUIC {
            rules.append(["network": "udp", "port": 443, "action": "reject"])
        }
        let resolver: [String: Any] = ["server": "boot-ali", "strategy": "ipv4_only"]
        let route: [String: Any] = [
            "rules": rules,
            "rule_set": [
                ruleSet("geosite-cn", repo: "sing-geosite", base: st.ruleSetBase),
                ruleSet("geoip-cn", repo: "sing-geoip", base: st.ruleSetBase),
            ],
            "final": "proxy",
            "auto_detect_interface": true,
            "default_domain_resolver": resolver,
        ]

        let root: [String: Any] = [
            "log": ["level": "warn", "timestamp": true] as [String: Any],
            "dns": dns,
            "inbounds": [tun],
            "outbounds": outbounds,
            "route": route,
            "experimental": ["cache_file": ["enabled": true, "path": "cache.db"] as [String: Any]] as [String: Any],
        ]
        let data = try JSONSerialization.data(
            withJSONObject: root, options: [.prettyPrinted, .sortedKeys, .withoutEscapingSlashes])
        return String(decoding: data, as: UTF8.self)
    }

    /// 优先使用 App Group 里打包好的本地规则集，避免首次启动下载失败导致内核起不来
    private static func ruleSet(_ tag: String, repo: String, base: String) -> [String: Any] {
        let local = AppGroup.container.appendingPathComponent("rules/\(tag).srs")
        if FileManager.default.fileExists(atPath: local.path) {
            return ["type": "local", "tag": tag, "format": "binary", "path": local.path]
        }
        return [
            "type": "remote", "tag": tag, "format": "binary",
            "url": "\(base)/\(repo)@rule-set/\(tag).srs",
            "download_detour": "direct", "update_interval": "3d",
        ]
    }

    private static func ne(_ s: String?) -> String? { (s?.isEmpty == false) ? s : nil }

    static func outbound(_ n: ProxyNode, tag: String) -> [String: Any] {
        var o: [String: Any] = [
            "tag": tag, "server": n.server, "server_port": n.port,
            "domain_resolver": ["server": "boot-ali", "strategy": "ipv4_only"] as [String: Any],
        ]
        switch n.kind {
        case .shadowsocks:
            o["type"] = "shadowsocks"
            o["method"] = n.method ?? "aes-128-gcm"
            o["password"] = n.password ?? ""
        case .vmess:
            o["type"] = "vmess"
            o["uuid"] = n.password ?? ""
            o["alter_id"] = n.alterID ?? 0
            o["security"] = "auto"
        case .vless:
            o["type"] = "vless"
            o["uuid"] = n.password ?? ""
            o["packet_encoding"] = "xudp"
            if let f = ne(n.flow) { o["flow"] = f }
        case .trojan:
            o["type"] = "trojan"
            o["password"] = n.password ?? ""
        case .hysteria2:
            o["type"] = "hysteria2"
            o["password"] = n.password ?? ""
        }

        let reality = n.security == "reality"
        if n.kind == .trojan || n.kind == .hysteria2 || n.security == "tls" || reality {
            var t: [String: Any] = ["enabled": true, "server_name": ne(n.sni) ?? n.server]
            if n.allowInsecure { t["insecure"] = true }
            if n.kind != .hysteria2, let fp = ne(n.fingerprint) ?? (reality ? "chrome" : nil) {
                t["utls"] = ["enabled": true, "fingerprint": fp] as [String: Any]
            }
            if reality, let pbk = ne(n.publicKey) {
                t["reality"] = ["enabled": true, "public_key": pbk, "short_id": n.shortID ?? ""] as [String: Any]
            }
            o["tls"] = t
        }

        if n.kind == .vmess || n.kind == .vless || n.kind == .trojan,
           let net = n.network, net == "ws" || net == "grpc" {
            var tr: [String: Any] = ["type": net]
            if net == "ws" {
                tr["path"] = ne(n.path) ?? "/"
                if let h = ne(n.host) { tr["headers"] = ["Host": h] as [String: Any] }
            } else {
                tr["service_name"] = n.path ?? ""
            }
            o["transport"] = tr
        }
        return o
    }
}
