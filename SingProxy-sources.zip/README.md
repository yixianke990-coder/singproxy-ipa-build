# SingProxy

SwiftUI + Packet Tunnel + sing-box (Libbox)。部署目标 iOS 18.0，iOS 26 / 27 自动启用 Liquid Glass。

## 工程设置
1. 新建 iOS App（SwiftUI），再加一个 Network Extension → Packet Tunnel Provider。
2. 两个 target 都开启：App Groups（同一个 group）、Network Extensions → Packet Tunnel。
3. 修改 `Shared/AppGroup.swift` 里的 group id 与扩展 Bundle ID。
4. `Shared/*` 同时加入 App 和 Extension；`App/*` 只加入 App；`Extension/*` 只加入 Extension。
5. 扩展 Info.plist：`NSExtensionPointIdentifier = com.apple.networkextension.packet-tunnel`，
   `NSExtensionPrincipalClass = $(PRODUCT_MODULE_NAME).PacketTunnelProvider`。
6. 把 Libbox.xcframework（按 sing-box 官方文档自行编译，需 1.12+）只链接到扩展。
7. Swift Language Mode 设为 5；Deployment Target 设为 iOS 18.0。
8. 不要在 Info.plist 里加 UIDesignRequiresCompatibility（Xcode 27 会忽略它）。
9. 建议把 geosite-cn.srs、geoip-cn.srs 放进 App 的 Copy Bundle Resources，首次启动不依赖网络。

## 必须真机调试（模拟器不支持 VPN，也不要用模拟器评估 Liquid Glass 效果）。

## 已知取舍
- 仅 IPv4：不设置 ipv6Settings，DNS 用 ipv4_only 不返回 AAAA；IPv6 字面量地址的流量不会进隧道。
- sing-box 一条 DNS 规则只能指向一个服务器，没有并发/故障转移，所以 8.8.8.8 与 1.1.1.1 做“主选切换”；
  国内则按域名拆分：腾讯系域名走腾讯 DoH，其余国内域名走阿里 DoH。
- 暂不支持：Clash YAML 订阅、ss 插件、hy2 端口跳跃。
