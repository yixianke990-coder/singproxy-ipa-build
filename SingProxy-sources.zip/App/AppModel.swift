import NetworkExtension
import SwiftUI

@MainActor
final class AppModel: ObservableObject {
    @Published var state = AppState() { didSet { save() } }
    @Published var status: NEVPNStatus = .disconnected
    @Published var toast: String?

    private var manager: NETunnelProviderManager?
    private var observer: NSObjectProtocol?

    var isOn: Bool { [NEVPNStatus.connected, .connecting, .reasserting].contains(status) }
    var statusText: String {
        switch status {
        case .connected: "已连接"
        case .connecting, .reasserting: "连接中…"
        case .disconnecting: "断开中…"
        default: "未连接"
        }
    }

    init() {
        if let d = try? Data(contentsOf: AppGroup.stateURL),
           let s = try? JSONDecoder().decode(AppState.self, from: d) { state = s }
        seedRuleSets()
        Task { await loadManager() }
    }

    // MARK: - 持久化
    private func save() {
        if let d = try? JSONEncoder().encode(state) { try? d.write(to: AppGroup.stateURL, options: .atomic) }
    }

    /// 把打包进 App 的 geosite-cn.srs / geoip-cn.srs 复制到 App Group，扩展里用本地规则集
    private func seedRuleSets() {
        let fm = FileManager.default
        let dir = AppGroup.container.appendingPathComponent("rules", isDirectory: true)
        try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
        for tag in ["geosite-cn", "geoip-cn"] {
            guard let src = Bundle.main.url(forResource: tag, withExtension: "srs") else { continue }
            let dst = dir.appendingPathComponent("\(tag).srs")
            try? fm.removeItem(at: dst)
            try? fm.copyItem(at: src, to: dst)
        }
    }

    // MARK: - 节点 / 订阅
    func importText(_ text: String) {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if t.lowercased().hasPrefix("http") {
            Task { await addSubscription(t) }
            return
        }
        let nodes = LinkParser.parseSubscription(t)
        guard !nodes.isEmpty else { toast = "没有识别到有效节点"; return }
        state.nodes += nodes
        toast = "已导入 \(nodes.count) 个节点"
    }

    func addSubscription(_ url: String) async {
        guard let u = URL(string: url) else { toast = "链接无效"; return }
        let sub = Subscription(name: u.host ?? "订阅", url: url)
        state.subscriptions.append(sub)
        await refresh(sub.id)
    }

    func refresh(_ id: UUID) async {
        guard let sub = state.subscriptions.first(where: { $0.id == id }), let u = URL(string: sub.url) else { return }
        var req = URLRequest(url: u)
        req.setValue("v2rayN/6.0", forHTTPHeaderField: "User-Agent")   // 让机场返回通用链接格式
        do {
            let (data, _) = try await URLSession.shared.data(for: req)
            let nodes = LinkParser.parseSubscription(String(decoding: data, as: UTF8.self)).map { n -> ProxyNode in
                var n = n; n.subscriptionID = id; return n
            }
            guard !nodes.isEmpty else { toast = "订阅里没有可识别的节点（暂不支持 Clash YAML 格式）"; return }
            state.nodes.removeAll { $0.subscriptionID == id }
            state.nodes += nodes
            if let j = state.subscriptions.firstIndex(where: { $0.id == id }) { state.subscriptions[j].updatedAt = .now }
            toast = "更新了 \(nodes.count) 个节点"
        } catch {
            toast = "更新失败：\(error.localizedDescription)"
        }
    }

    func refreshAll() async {
        for s in state.subscriptions { await refresh(s.id) }
    }

    // MARK: - VPN
    private func loadManager() async {
        let all = (try? await NETunnelProviderManager.loadAllFromPreferences()) ?? []
        if let m = all.first {
            manager = m
            observe(m)
            status = m.connection.status
        }
    }

    private func observe(_ m: NETunnelProviderManager) {
        if let observer { NotificationCenter.default.removeObserver(observer) }
        observer = NotificationCenter.default.addObserver(
            forName: .NEVPNStatusDidChange, object: m.connection, queue: .main
        ) { [weak self] _ in
            MainActor.assumeIsolated { self?.status = m.connection.status }
        }
    }

    func toggle() async {
        if isOn { manager?.connection.stopVPNTunnel(); return }
        do {
            let json = try ConfigBuilder.build(state)
            try json.write(to: AppGroup.configURL, atomically: true, encoding: .utf8)

            let m = manager ?? NETunnelProviderManager()
            let p = NETunnelProviderProtocol()
            p.providerBundleIdentifier = AppGroup.tunnelBundleID
            p.serverAddress = "SingProxy"
            m.protocolConfiguration = p
            m.localizedDescription = "SingProxy"
            m.isEnabled = true
            try await m.saveToPreferences()
            try await m.loadFromPreferences()
            manager = m
            observe(m)
            try m.connection.startVPNTunnel()
        } catch {
            toast = error.localizedDescription
        }
    }
}
